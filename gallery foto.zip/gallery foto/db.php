<?php
$hostname = 'localhist';
$username = 'root';
$password = '';
$dbname = 'galleryfoto';

$conn = mysqli_connect($hostname, $username, $password, $dbname) or die ('gagal terhubung ke database');
?>