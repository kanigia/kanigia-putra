<?php 

session_start();
include "koneksi.php";

if(isset($_POST['tambah'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];

    $foto_pro = $_FILES['namafoto_pro']['name'];
    $tmp = $_FILES['namafoto_pro']['tmp_name'];

    if(isset($_FILES['namafoto_pro']) && $_FILES['namafoto_pro']['error'] === 0){
        
        $lokasi_pro = 'assets/img/';
        $namafoto_pro = $foto_pro;

        move_uploaded_file($tmp, $lokasi_pro . $namafoto_pro);

        $check_query = "SELECT * FROM user WHERE username='$username'";
        $result = mysqli_query($conn, $check_query);

        if(mysqli_num_rows($result) > 0){
            echo "<acript>
                alert('Nama pengguna sudah digunakan.Silahkan pilih nama pengguna lain.');
                location.href = 'register.php?status=gagal';
            </script>";
        }else{
            $sql = mysqli_query($conn, "INSERT INTO user (username, password, email, namalengkap, alamat, namafoto_pro)
            VALUE ('$username', '$password', '$email', '$nama', '$alamat', '$namafoto_pro')");

            if($sql){
                echo "<script>
                    alert('Pendaftaran Akun Berhasil.');
                    location.href = 'login.php?status=berhasil';
                </script>";
            }else{
                echo "<script>
                    alert('Pendaftaran Akun Gagal.Silahkan Coba Lagi');
                    location.href = 'register.php?status=gagal';
                </script>";
            }
        }
    }else{
        echo "<script>
            alert('file gagal diunggah.Silahkan Coba Lagi');
            location.href = 'register.php?status=gagal';
        </script>";
    }
}